# 1.Calcula la divisiÃ³n entera de 45 entre 6 #
divisionEntera = 45 // 6
print(divisionEntera)
print()
# 2.Calcula el resto de la divisiÃ³n entera de 45 entre 6 #
restoDivision = 54 % 6
print(restoDivision)
print()
# 3.Realiza la siguiente operaciÃ³n en Python, donde Ã· indica la divisiÃ³n entera #
operacionDivisionEntera = 10 + 20 // 7 - 2
print(operacionDivisionEntera)
print()
# 4.Realiza la siguiente operacion en Python #
resultado = ((9 - 25 + 5 - 2) / (7 * 4)) / (2**3)
print(resultado)
print()
# 5.Realiza la siguiente operacion en Python #
numerador = 2 + 2**3 - 2 * (2 - 2**5) + 2**2 * 2 + 2
denominador = 2 * (2 * 2 - 2**4) + 2**2
resultado = numerador / denominador
print(resultado)
print()
# 6.Realiza la siguiente operacion en Python #
import numpy as np
# Definir los nÃºmeros complejos
i = 1j
expresion = 6*i - (4 + i) * 2
print(expresion)
print()
# 7.Realiza la siguiente operacion en Python #
# Definir los nÃºmeros complejos
i = 1j

# Calcular las dos fracciones
fraccion1 = (1 + i) / (1 - i)
fraccion2 = 2 / (-1 + i)

# Sumar las dos fracciones
resultado = fraccion1 + fraccion2

# Mostrar el resultado
print(resultado)
print()
# 8.Realiza la siguiente operacion en Python #
# Definimos el nÃºmero complejo i
i = 1j

# Calculamos la expresiÃ³n
y = (1 + i) ** 2

# Imprimimos el resultado
print("y =", y)
print()
# 9.Realiza la siguiente operaciÃ³n en Python, donde Mod(z) indica mÃ³dulo del complejo z: Mod  #
import cmath

# Definimos el nÃºmero complejo
z = (9 - 3j) / (-2 - 1j)

# Calculamos el mÃ³dulo
modulo_z = abs(z)

# Imprimimos el resultado
print(f"El mÃ³dulo de z es {modulo_z:.6f}")
print()
# 10 Â¿CuÃ¡l es el argumento del nÃºmero complejo i?: #

import cmath

# Definimos el nÃºmero complejo i
i = 1j

# Calculamos el argumento en radianes
argumento_radianes = cmath.phase(i)

print(f"El argumento de i en radianes es {argumento_radianes:.6f}")







